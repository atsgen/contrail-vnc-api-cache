//
// Automatically generated. DO NOT EDIT.
//

package types

type PortType struct {
	StartPort int `json:"start_port,omitempty"`
	EndPort int `json:"end_port,omitempty"`
}
