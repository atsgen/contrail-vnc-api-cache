//
// Automatically generated. DO NOT EDIT.
//

package types

type AllocationPoolType struct {
	Start string `json:"start,omitempty"`
	End string `json:"end,omitempty"`
	VrouterSpecificPool bool `json:"vrouter_specific_pool,omitempty"`
}
