//
// Automatically generated. DO NOT EDIT.
//

package types

type BGPaaServiceParametersType struct {
	PortStart int `json:"port_start,omitempty"`
	PortEnd int `json:"port_end,omitempty"`
}
