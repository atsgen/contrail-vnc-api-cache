//
// Automatically generated. DO NOT EDIT.
//

package types

type AsnRangeType struct {
	AsnMin int `json:"asn_min,omitempty"`
	AsnMax int `json:"asn_max,omitempty"`
}
