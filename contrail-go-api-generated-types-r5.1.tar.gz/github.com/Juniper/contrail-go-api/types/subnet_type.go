//
// Automatically generated. DO NOT EDIT.
//

package types

type SubnetType struct {
	IpPrefix string `json:"ip_prefix,omitempty"`
	IpPrefixLen int `json:"ip_prefix_len,omitempty"`
}
