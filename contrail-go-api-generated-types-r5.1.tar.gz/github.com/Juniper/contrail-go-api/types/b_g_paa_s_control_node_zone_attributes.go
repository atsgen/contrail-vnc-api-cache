//
// Automatically generated. DO NOT EDIT.
//

package types

type BGPaaSControlNodeZoneAttributes struct {
	BgpaasControlNodeZoneType string `json:"bgpaas_control_node_zone_type,omitempty"`
}
