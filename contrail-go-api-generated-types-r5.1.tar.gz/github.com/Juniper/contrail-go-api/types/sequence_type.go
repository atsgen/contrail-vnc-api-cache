//
// Automatically generated. DO NOT EDIT.
//

package types

type SequenceType struct {
	Major int `json:"major,omitempty"`
	Minor int `json:"minor,omitempty"`
}
