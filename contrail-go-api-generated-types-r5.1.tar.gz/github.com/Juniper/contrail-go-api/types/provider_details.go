//
// Automatically generated. DO NOT EDIT.
//

package types

type ProviderDetails struct {
	SegmentationId int `json:"segmentation_id,omitempty"`
	PhysicalNetwork string `json:"physical_network,omitempty"`
}
