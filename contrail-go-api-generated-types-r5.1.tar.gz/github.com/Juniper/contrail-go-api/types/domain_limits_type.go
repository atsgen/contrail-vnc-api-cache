//
// Automatically generated. DO NOT EDIT.
//

package types

type DomainLimitsType struct {
	ProjectLimit int `json:"project_limit,omitempty"`
	VirtualNetworkLimit int `json:"virtual_network_limit,omitempty"`
	SecurityGroupLimit int `json:"security_group_limit,omitempty"`
}
