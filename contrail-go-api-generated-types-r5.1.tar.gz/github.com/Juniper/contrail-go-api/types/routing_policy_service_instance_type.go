//
// Automatically generated. DO NOT EDIT.
//

package types

type RoutingPolicyServiceInstanceType struct {
	LeftSequence string `json:"left_sequence,omitempty"`
	RightSequence string `json:"right_sequence,omitempty"`
}
