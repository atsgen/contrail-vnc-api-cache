//
// Automatically generated. DO NOT EDIT.
//

package types

type BridgeDomainMembershipType struct {
	VlanTag int `json:"vlan_tag,omitempty"`
}
