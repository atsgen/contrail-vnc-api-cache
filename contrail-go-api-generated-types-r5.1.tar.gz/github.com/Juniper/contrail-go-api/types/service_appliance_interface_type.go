//
// Automatically generated. DO NOT EDIT.
//

package types

type ServiceApplianceInterfaceType struct {
	InterfaceType string `json:"interface_type,omitempty"`
}
