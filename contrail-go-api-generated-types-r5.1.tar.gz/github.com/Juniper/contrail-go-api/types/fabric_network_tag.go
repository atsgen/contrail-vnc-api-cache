//
// Automatically generated. DO NOT EDIT.
//

package types

type FabricNetworkTag struct {
	NetworkType string `json:"network_type,omitempty"`
}
