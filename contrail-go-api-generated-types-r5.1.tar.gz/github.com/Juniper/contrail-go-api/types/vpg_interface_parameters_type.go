//
// Automatically generated. DO NOT EDIT.
//

package types

type VpgInterfaceParametersType struct {
	AeNum int `json:"ae_num,omitempty"`
}
