//
// Automatically generated. DO NOT EDIT.
//

package types

type ControlTrafficDscpType struct {
	Control int `json:"control,omitempty"`
	Analytics int `json:"analytics,omitempty"`
	Dns int `json:"dns,omitempty"`
}
