//
// Automatically generated. DO NOT EDIT.
//

package types

type AllowedAddressPair struct {
	Ip *SubnetType `json:"ip,omitempty"`
	Mac string `json:"mac,omitempty"`
	AddressMode string `json:"address_mode,omitempty"`
}
