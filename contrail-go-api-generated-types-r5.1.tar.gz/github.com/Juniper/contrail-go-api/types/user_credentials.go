//
// Automatically generated. DO NOT EDIT.
//

package types

type UserCredentials struct {
	Username string `json:"username,omitempty"`
	Password string `json:"password,omitempty"`
}
