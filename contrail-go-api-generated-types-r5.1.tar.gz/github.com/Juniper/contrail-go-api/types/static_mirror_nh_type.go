//
// Automatically generated. DO NOT EDIT.
//

package types

type StaticMirrorNhType struct {
	VtepDstIpAddress string `json:"vtep_dst_ip_address,omitempty"`
	VtepDstMacAddress string `json:"vtep_dst_mac_address,omitempty"`
	Vni int `json:"vni,omitempty"`
}
