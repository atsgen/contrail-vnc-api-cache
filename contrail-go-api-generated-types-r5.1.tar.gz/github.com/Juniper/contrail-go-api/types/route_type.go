//
// Automatically generated. DO NOT EDIT.
//

package types

type RouteType struct {
	Prefix string `json:"prefix,omitempty"`
	NextHop string `json:"next_hop,omitempty"`
	NextHopType string `json:"next_hop_type,omitempty"`
	CommunityAttributes *CommunityAttributes `json:"community_attributes,omitempty"`
}
