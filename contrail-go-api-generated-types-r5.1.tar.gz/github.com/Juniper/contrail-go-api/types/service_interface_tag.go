//
// Automatically generated. DO NOT EDIT.
//

package types

type ServiceInterfaceTag struct {
	InterfaceType string `json:"interface_type,omitempty"`
}
