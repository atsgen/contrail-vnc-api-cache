//
// Automatically generated. DO NOT EDIT.
//

package types

type MACLimitControlType struct {
	MacLimit int `json:"mac_limit,omitempty"`
	MacLimitAction string `json:"mac_limit_action,omitempty"`
}
