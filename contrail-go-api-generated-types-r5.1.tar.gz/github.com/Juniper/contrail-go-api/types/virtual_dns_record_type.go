//
// Automatically generated. DO NOT EDIT.
//

package types

type VirtualDnsRecordType struct {
	RecordName string `json:"record_name,omitempty"`
	RecordType string `json:"record_type,omitempty"`
	RecordClass string `json:"record_class,omitempty"`
	RecordData string `json:"record_data,omitempty"`
	RecordTtlSeconds int `json:"record_ttl_seconds,omitempty"`
	RecordMxPreference int `json:"record_mx_preference,omitempty"`
}
