//
// Automatically generated. DO NOT EDIT.
//

package types

type LogicalRouterVirtualNetworkType struct {
	LogicalRouterVirtualNetworkType string `json:"logical_router_virtual_network_type,omitempty"`
}
