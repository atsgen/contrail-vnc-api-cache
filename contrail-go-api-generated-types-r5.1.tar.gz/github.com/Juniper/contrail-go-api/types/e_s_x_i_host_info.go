//
// Automatically generated. DO NOT EDIT.
//

package types

type ESXIHostInfo struct {
	Username string `json:"username,omitempty"`
	Datacenter string `json:"datacenter,omitempty"`
	EsxiName string `json:"esxi_name,omitempty"`
	Cluster string `json:"cluster,omitempty"`
	Mac string `json:"mac,omitempty"`
	Datastore string `json:"datastore,omitempty"`
	Password string `json:"password,omitempty"`
	VcenterServer string `json:"vcenter_server,omitempty"`
}
