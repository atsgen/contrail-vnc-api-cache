//
// Automatically generated. DO NOT EDIT.
//

package types

type EcmpHashingIncludeFields struct {
	HashingConfigured bool `json:"hashing_configured,omitempty"`
	SourceIp bool `json:"source_ip,omitempty"`
	DestinationIp bool `json:"destination_ip,omitempty"`
	IpProtocol bool `json:"ip_protocol,omitempty"`
	SourcePort bool `json:"source_port,omitempty"`
	DestinationPort bool `json:"destination_port,omitempty"`
}
