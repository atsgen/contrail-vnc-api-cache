//
// Automatically generated. DO NOT EDIT.
//

package types

type SloRateType struct {
	Rate int `json:"rate,omitempty"`
}
