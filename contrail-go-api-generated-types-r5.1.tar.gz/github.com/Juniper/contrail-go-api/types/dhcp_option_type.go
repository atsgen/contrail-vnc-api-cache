//
// Automatically generated. DO NOT EDIT.
//

package types

type DhcpOptionType struct {
	DhcpOptionName string `json:"dhcp_option_name,omitempty"`
	DhcpOptionValue string `json:"dhcp_option_value,omitempty"`
	DhcpOptionValueBytes string `json:"dhcp_option_value_bytes,omitempty"`
}
