//
// Automatically generated. DO NOT EDIT.
//

package types

type FirewallSequence struct {
	Sequence string `json:"sequence,omitempty"`
}
