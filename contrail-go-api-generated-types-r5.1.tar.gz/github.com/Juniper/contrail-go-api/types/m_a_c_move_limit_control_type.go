//
// Automatically generated. DO NOT EDIT.
//

package types

type MACMoveLimitControlType struct {
	MacMoveLimit int `json:"mac_move_limit,omitempty"`
	MacMoveTimeWindow int `json:"mac_move_time_window,omitempty"`
	MacMoveLimitAction string `json:"mac_move_limit_action,omitempty"`
}
